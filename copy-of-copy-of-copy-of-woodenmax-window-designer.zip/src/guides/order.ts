// This file defines the order of guides in the GuidesViewer sidebar.

export const guideOrder: string[] = [
    'index',
    'sliding',
    'casement',
    'bifold',
    'ventilator',
    'glass_partition',
    'louvers',
    'corner',
    'mirror',
    'georgian_bars',
    'qna'
];